﻿namespace Virtualpad
{
    partial class KeyBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KeyBoard));
            this.EnglishKeyBoard = new System.Windows.Forms.Panel();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.PicExit = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Pic_Copy = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.Left = new System.Windows.Forms.ToolStripMenuItem();
            this.Center = new System.Windows.Forms.ToolStripMenuItem();
            this.Right = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSplitButton2 = new System.Windows.Forms.ToolStripSplitButton();
            this.Engilsh = new System.Windows.Forms.ToolStripMenuItem();
            this.Persian = new System.Windows.Forms.ToolStripMenuItem();
            this.PersianKeyBoard = new System.Windows.Forms.Panel();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.Button35 = new System.Windows.Forms.Button();
            this.Button34 = new System.Windows.Forms.Button();
            this.Button33 = new System.Windows.Forms.Button();
            this.Button32 = new System.Windows.Forms.Button();
            this.Button31 = new System.Windows.Forms.Button();
            this.Button30 = new System.Windows.Forms.Button();
            this.Button29 = new System.Windows.Forms.Button();
            this.Button28 = new System.Windows.Forms.Button();
            this.Button18 = new System.Windows.Forms.Button();
            this.Button17 = new System.Windows.Forms.Button();
            this.Button13 = new System.Windows.Forms.Button();
            this.Button14 = new System.Windows.Forms.Button();
            this.Button23 = new System.Windows.Forms.Button();
            this.Button25 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button27 = new System.Windows.Forms.Button();
            this.Button24 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button26 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button20 = new System.Windows.Forms.Button();
            this.Button22 = new System.Windows.Forms.Button();
            this.Button12 = new System.Windows.Forms.Button();
            this.Button16 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.Button19 = new System.Windows.Forms.Button();
            this.Button10 = new System.Windows.Forms.Button();
            this.Button15 = new System.Windows.Forms.Button();
            this.Button8 = new System.Windows.Forms.Button();
            this.Button21 = new System.Windows.Forms.Button();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.Characters = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Lines = new System.Windows.Forms.ToolStripStatusLabel();
            this.EnglishKeyBoard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Copy)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.PersianKeyBoard.SuspendLayout();
            this.SuspendLayout();
            // 
            // EnglishKeyBoard
            // 
            this.EnglishKeyBoard.BackColor = System.Drawing.Color.Transparent;
            this.EnglishKeyBoard.Controls.Add(this.button73);
            this.EnglishKeyBoard.Controls.Add(this.button74);
            this.EnglishKeyBoard.Controls.Add(this.button75);
            this.EnglishKeyBoard.Controls.Add(this.button76);
            this.EnglishKeyBoard.Controls.Add(this.button77);
            this.EnglishKeyBoard.Controls.Add(this.button78);
            this.EnglishKeyBoard.Controls.Add(this.button79);
            this.EnglishKeyBoard.Controls.Add(this.button80);
            this.EnglishKeyBoard.Controls.Add(this.button81);
            this.EnglishKeyBoard.Controls.Add(this.button82);
            this.EnglishKeyBoard.Controls.Add(this.button83);
            this.EnglishKeyBoard.Controls.Add(this.button84);
            this.EnglishKeyBoard.Controls.Add(this.button85);
            this.EnglishKeyBoard.Controls.Add(this.button37);
            this.EnglishKeyBoard.Controls.Add(this.button38);
            this.EnglishKeyBoard.Controls.Add(this.button39);
            this.EnglishKeyBoard.Controls.Add(this.button40);
            this.EnglishKeyBoard.Controls.Add(this.button41);
            this.EnglishKeyBoard.Controls.Add(this.button42);
            this.EnglishKeyBoard.Controls.Add(this.button43);
            this.EnglishKeyBoard.Controls.Add(this.button44);
            this.EnglishKeyBoard.Controls.Add(this.button45);
            this.EnglishKeyBoard.Controls.Add(this.button46);
            this.EnglishKeyBoard.Controls.Add(this.button47);
            this.EnglishKeyBoard.Controls.Add(this.button48);
            this.EnglishKeyBoard.Controls.Add(this.button49);
            this.EnglishKeyBoard.Controls.Add(this.button50);
            this.EnglishKeyBoard.Controls.Add(this.button51);
            this.EnglishKeyBoard.Controls.Add(this.button52);
            this.EnglishKeyBoard.Controls.Add(this.button53);
            this.EnglishKeyBoard.Controls.Add(this.button54);
            this.EnglishKeyBoard.Controls.Add(this.button55);
            this.EnglishKeyBoard.Controls.Add(this.button56);
            this.EnglishKeyBoard.Controls.Add(this.button57);
            this.EnglishKeyBoard.Controls.Add(this.button58);
            this.EnglishKeyBoard.Controls.Add(this.button59);
            this.EnglishKeyBoard.Controls.Add(this.button60);
            this.EnglishKeyBoard.Controls.Add(this.button61);
            this.EnglishKeyBoard.Controls.Add(this.button62);
            this.EnglishKeyBoard.Controls.Add(this.button63);
            this.EnglishKeyBoard.Controls.Add(this.button64);
            this.EnglishKeyBoard.Controls.Add(this.button65);
            this.EnglishKeyBoard.Controls.Add(this.button66);
            this.EnglishKeyBoard.Controls.Add(this.button67);
            this.EnglishKeyBoard.Controls.Add(this.button68);
            this.EnglishKeyBoard.Controls.Add(this.button69);
            this.EnglishKeyBoard.Controls.Add(this.button70);
            this.EnglishKeyBoard.Controls.Add(this.button71);
            this.EnglishKeyBoard.Controls.Add(this.button72);
            this.EnglishKeyBoard.Location = new System.Drawing.Point(23, 119);
            this.EnglishKeyBoard.Name = "EnglishKeyBoard";
            this.EnglishKeyBoard.Size = new System.Drawing.Size(342, 121);
            this.EnglishKeyBoard.TabIndex = 12;
            // 
            // button73
            // 
            this.button73.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button73.Location = new System.Drawing.Point(283, 3);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(19, 23);
            this.button73.TabIndex = 111;
            this.button73.Text = "+";
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.button76_Click);
            // 
            // button74
            // 
            this.button74.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button74.Location = new System.Drawing.Point(260, 3);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(19, 23);
            this.button74.TabIndex = 110;
            this.button74.Text = "-";
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.button76_Click);
            // 
            // button75
            // 
            this.button75.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button75.Location = new System.Drawing.Point(305, 3);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(31, 23);
            this.button75.TabIndex = 109;
            this.button75.Text = "=";
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.button76_Click);
            // 
            // button76
            // 
            this.button76.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button76.Location = new System.Drawing.Point(3, 3);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(19, 23);
            this.button76.TabIndex = 103;
            this.button76.Text = "1";
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // button77
            // 
            this.button77.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button77.Location = new System.Drawing.Point(28, 3);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(19, 23);
            this.button77.TabIndex = 107;
            this.button77.Text = "2";
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button76_Click);
            // 
            // button78
            // 
            this.button78.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button78.Location = new System.Drawing.Point(132, 3);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(19, 23);
            this.button78.TabIndex = 108;
            this.button78.Text = "6";
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.button76_Click);
            // 
            // button79
            // 
            this.button79.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button79.Location = new System.Drawing.Point(54, 3);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(19, 23);
            this.button79.TabIndex = 99;
            this.button79.Text = "3";
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.button76_Click);
            // 
            // button80
            // 
            this.button80.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button80.Location = new System.Drawing.Point(158, 3);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(19, 23);
            this.button80.TabIndex = 106;
            this.button80.Text = "7";
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.button76_Click);
            // 
            // button81
            // 
            this.button81.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button81.Location = new System.Drawing.Point(236, 3);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(19, 23);
            this.button81.TabIndex = 102;
            this.button81.Text = "0";
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.button76_Click);
            // 
            // button82
            // 
            this.button82.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button82.Location = new System.Drawing.Point(80, 3);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(19, 23);
            this.button82.TabIndex = 104;
            this.button82.Text = "4";
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.button76_Click);
            // 
            // button83
            // 
            this.button83.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button83.Location = new System.Drawing.Point(210, 3);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(20, 23);
            this.button83.TabIndex = 101;
            this.button83.Text = "9";
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Click += new System.EventHandler(this.button76_Click);
            // 
            // button84
            // 
            this.button84.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button84.Location = new System.Drawing.Point(106, 3);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(19, 23);
            this.button84.TabIndex = 105;
            this.button84.Text = "5";
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.button76_Click);
            // 
            // button85
            // 
            this.button85.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button85.Location = new System.Drawing.Point(184, 3);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(19, 23);
            this.button85.TabIndex = 100;
            this.button85.Text = "8";
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Click += new System.EventHandler(this.button76_Click);
            // 
            // button37
            // 
            this.button37.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button37.Location = new System.Drawing.Point(318, 90);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(19, 23);
            this.button37.TabIndex = 98;
            this.button37.Text = "/";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button76_Click);
            // 
            // button38
            // 
            this.button38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button38.Location = new System.Drawing.Point(81, 90);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(19, 23);
            this.button38.TabIndex = 97;
            this.button38.Text = "v";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button76_Click);
            // 
            // button39
            // 
            this.button39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button39.Location = new System.Drawing.Point(294, 90);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(19, 23);
            this.button39.TabIndex = 96;
            this.button39.Text = ".";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button76_Click);
            // 
            // button40
            // 
            this.button40.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button40.Location = new System.Drawing.Point(260, 61);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(19, 23);
            this.button40.TabIndex = 95;
            this.button40.Text = "\'";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button76_Click);
            // 
            // button41
            // 
            this.button41.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button41.Location = new System.Drawing.Point(236, 61);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(19, 23);
            this.button41.TabIndex = 94;
            this.button41.Text = ";";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button76_Click);
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button42.Location = new System.Drawing.Point(283, 32);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(19, 23);
            this.button42.TabIndex = 93;
            this.button42.Text = "}";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button76_Click);
            // 
            // button43
            // 
            this.button43.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button43.Location = new System.Drawing.Point(260, 32);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(19, 23);
            this.button43.TabIndex = 92;
            this.button43.Text = "{";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button76_Click);
            // 
            // button44
            // 
            this.button44.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button44.Location = new System.Drawing.Point(305, 32);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(31, 23);
            this.button44.TabIndex = 91;
            this.button44.Text = "<---";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button45
            // 
            this.button45.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button45.Location = new System.Drawing.Point(181, 90);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(83, 23);
            this.button45.TabIndex = 90;
            this.button45.Text = "Space";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button46.Location = new System.Drawing.Point(283, 61);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(53, 23);
            this.button46.TabIndex = 89;
            this.button46.Text = "Enter";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button47.Location = new System.Drawing.Point(3, 32);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(19, 23);
            this.button47.TabIndex = 79;
            this.button47.Text = "q";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button76_Click);
            // 
            // button48
            // 
            this.button48.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button48.Location = new System.Drawing.Point(269, 90);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(19, 23);
            this.button48.TabIndex = 75;
            this.button48.Text = ",";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button76_Click);
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button49.Location = new System.Drawing.Point(157, 90);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(19, 23);
            this.button49.TabIndex = 76;
            this.button49.Text = "m";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button76_Click);
            // 
            // button50
            // 
            this.button50.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button50.Location = new System.Drawing.Point(107, 90);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(19, 23);
            this.button50.TabIndex = 84;
            this.button50.Text = "b";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button76_Click);
            // 
            // button51
            // 
            this.button51.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button51.Location = new System.Drawing.Point(29, 90);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(19, 23);
            this.button51.TabIndex = 86;
            this.button51.Text = "x";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button76_Click);
            // 
            // button52
            // 
            this.button52.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button52.Location = new System.Drawing.Point(133, 90);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(19, 23);
            this.button52.TabIndex = 64;
            this.button52.Text = "n";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button76_Click);
            // 
            // button53
            // 
            this.button53.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button53.Location = new System.Drawing.Point(3, 90);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(19, 23);
            this.button53.TabIndex = 88;
            this.button53.Text = "z";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button76_Click);
            // 
            // button54
            // 
            this.button54.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button54.Location = new System.Drawing.Point(28, 32);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(19, 23);
            this.button54.TabIndex = 85;
            this.button54.Text = "w";
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button76_Click);
            // 
            // button55
            // 
            this.button55.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button55.Location = new System.Drawing.Point(55, 90);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(19, 23);
            this.button55.TabIndex = 65;
            this.button55.Text = "c";
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button76_Click);
            // 
            // button56
            // 
            this.button56.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button56.Location = new System.Drawing.Point(132, 32);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(19, 23);
            this.button56.TabIndex = 87;
            this.button56.Text = "y";
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button76_Click);
            // 
            // button57
            // 
            this.button57.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button57.Location = new System.Drawing.Point(54, 32);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(19, 23);
            this.button57.TabIndex = 67;
            this.button57.Text = "e";
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button76_Click);
            // 
            // button58
            // 
            this.button58.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button58.Location = new System.Drawing.Point(28, 61);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(19, 23);
            this.button58.TabIndex = 81;
            this.button58.Text = "s";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button76_Click);
            // 
            // button59
            // 
            this.button59.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button59.Location = new System.Drawing.Point(158, 32);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(19, 23);
            this.button59.TabIndex = 83;
            this.button59.Text = "u";
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button76_Click);
            // 
            // button60
            // 
            this.button60.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button60.Location = new System.Drawing.Point(207, 61);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(19, 23);
            this.button60.TabIndex = 74;
            this.button60.Text = "l";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button76_Click);
            // 
            // button61
            // 
            this.button61.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button61.Location = new System.Drawing.Point(236, 32);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(19, 23);
            this.button61.TabIndex = 78;
            this.button61.Text = "p";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button76_Click);
            // 
            // button62
            // 
            this.button62.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button62.Location = new System.Drawing.Point(181, 61);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(19, 23);
            this.button62.TabIndex = 73;
            this.button62.Text = "k";
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button76_Click);
            // 
            // button63
            // 
            this.button63.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button63.Location = new System.Drawing.Point(80, 32);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(19, 23);
            this.button63.TabIndex = 80;
            this.button63.Text = "r";
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button76_Click);
            // 
            // button64
            // 
            this.button64.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button64.Location = new System.Drawing.Point(156, 61);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(19, 23);
            this.button64.TabIndex = 72;
            this.button64.Text = "j";
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button76_Click);
            // 
            // button65
            // 
            this.button65.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button65.Location = new System.Drawing.Point(210, 32);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(20, 23);
            this.button65.TabIndex = 77;
            this.button65.Text = "o";
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button76_Click);
            // 
            // button66
            // 
            this.button66.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button66.Location = new System.Drawing.Point(132, 61);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(19, 23);
            this.button66.TabIndex = 70;
            this.button66.Text = "h";
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button76_Click);
            // 
            // button67
            // 
            this.button67.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button67.Location = new System.Drawing.Point(106, 32);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(19, 23);
            this.button67.TabIndex = 82;
            this.button67.Text = "t";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button76_Click);
            // 
            // button68
            // 
            this.button68.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button68.Location = new System.Drawing.Point(106, 61);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(19, 23);
            this.button68.TabIndex = 69;
            this.button68.Text = "g";
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button76_Click);
            // 
            // button69
            // 
            this.button69.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button69.Location = new System.Drawing.Point(184, 32);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(19, 23);
            this.button69.TabIndex = 71;
            this.button69.Text = "i";
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button76_Click);
            // 
            // button70
            // 
            this.button70.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button70.Location = new System.Drawing.Point(80, 61);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(19, 23);
            this.button70.TabIndex = 68;
            this.button70.Text = "f";
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.button76_Click);
            // 
            // button71
            // 
            this.button71.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button71.Location = new System.Drawing.Point(3, 61);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(19, 23);
            this.button71.TabIndex = 63;
            this.button71.Text = "a";
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.button76_Click);
            // 
            // button72
            // 
            this.button72.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button72.Location = new System.Drawing.Point(54, 61);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(19, 23);
            this.button72.TabIndex = 66;
            this.button72.Text = "d";
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.button76_Click);
            // 
            // PicExit
            // 
            this.PicExit.Image = global::Virtualpad.Properties.Resources.ic_settings_power_black_48dp;
            this.PicExit.Location = new System.Drawing.Point(361, 2);
            this.PicExit.Name = "PicExit";
            this.PicExit.Size = new System.Drawing.Size(24, 26);
            this.PicExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PicExit.TabIndex = 13;
            this.PicExit.TabStop = false;
            this.PicExit.Click += new System.EventHandler(this.PicExit_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(6, 34);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(379, 79);
            this.richTextBox1.TabIndex = 14;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Pic_Copy
            // 
            this.Pic_Copy.Image = global::Virtualpad.Properties.Resources.copy;
            this.Pic_Copy.Location = new System.Drawing.Point(6, 2);
            this.Pic_Copy.Name = "Pic_Copy";
            this.Pic_Copy.Size = new System.Drawing.Size(33, 26);
            this.Pic_Copy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Pic_Copy.TabIndex = 15;
            this.Pic_Copy.TabStop = false;
            this.toolTip1.SetToolTip(this.Pic_Copy, "کپی کردن متن داخل فیلد");
            this.Pic_Copy.Click += new System.EventHandler(this.Pic_Copy_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton1,
            this.toolStripSplitButton2,
            this.toolStripSeparator2,
            this.toolStripStatusLabel1,
            this.toolStripSeparator5,
            this.toolStripStatusLabel3,
            this.Characters,
            this.toolStripSeparator6,
            this.toolStripStatusLabel5,
            this.Lines});
            this.statusStrip1.Location = new System.Drawing.Point(0, 242);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(397, 23);
            this.statusStrip1.TabIndex = 16;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Left,
            this.Center,
            this.Right});
            this.toolStripSplitButton1.Image = global::Virtualpad.Properties.Resources.right_alignment;
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStripSplitButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 21);
            this.toolStripSplitButton1.Text = "toolStripSplitButton1";
            this.toolStripSplitButton1.ToolTipText = "تنظیم کردن چینش متن";
            // 
            // Left
            // 
            this.Left.Image = global::Virtualpad.Properties.Resources.right_alignment1;
            this.Left.Name = "Left";
            this.Left.Size = new System.Drawing.Size(152, 22);
            this.Left.Text = "چپ چین";
            this.Left.Click += new System.EventHandler(this.Left_Click);
            // 
            // Center
            // 
            this.Center.Image = global::Virtualpad.Properties.Resources.center_alignment;
            this.Center.Name = "Center";
            this.Center.Size = new System.Drawing.Size(152, 22);
            this.Center.Text = "وسط چین";
            this.Center.Click += new System.EventHandler(this.Center_Click);
            // 
            // Right
            // 
            this.Right.Image = global::Virtualpad.Properties.Resources.right_alignment;
            this.Right.Name = "Right";
            this.Right.Size = new System.Drawing.Size(152, 22);
            this.Right.Text = "راست چین";
            this.Right.Click += new System.EventHandler(this.Right_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(134, 18);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.Click += new System.EventHandler(this.button46_Click);
            // 
            // toolStripSplitButton2
            // 
            this.toolStripSplitButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Persian,
            this.Engilsh});
            this.toolStripSplitButton2.Image = global::Virtualpad.Properties.Resources.keyboard;
            this.toolStripSplitButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton2.Name = "toolStripSplitButton2";
            this.toolStripSplitButton2.Size = new System.Drawing.Size(32, 21);
            this.toolStripSplitButton2.Text = "toolStripSplitButton2";
            // 
            // Engilsh
            // 
            this.Engilsh.Image = ((System.Drawing.Image)(resources.GetObject("Engilsh.Image")));
            this.Engilsh.Name = "Engilsh";
            this.Engilsh.Size = new System.Drawing.Size(152, 22);
            this.Engilsh.Text = "English";
            this.Engilsh.Click += new System.EventHandler(this.Engilsh_Click);
            // 
            // Persian
            // 
            this.Persian.Image = ((System.Drawing.Image)(resources.GetObject("Persian.Image")));
            this.Persian.Name = "Persian";
            this.Persian.Size = new System.Drawing.Size(152, 22);
            this.Persian.Text = "Persian";
            this.Persian.Click += new System.EventHandler(this.Persian_Click);
            // 
            // PersianKeyBoard
            // 
            this.PersianKeyBoard.Controls.Add(this.button86);
            this.PersianKeyBoard.Controls.Add(this.button87);
            this.PersianKeyBoard.Controls.Add(this.button88);
            this.PersianKeyBoard.Controls.Add(this.button89);
            this.PersianKeyBoard.Controls.Add(this.button90);
            this.PersianKeyBoard.Controls.Add(this.button91);
            this.PersianKeyBoard.Controls.Add(this.button92);
            this.PersianKeyBoard.Controls.Add(this.button93);
            this.PersianKeyBoard.Controls.Add(this.button94);
            this.PersianKeyBoard.Controls.Add(this.button95);
            this.PersianKeyBoard.Controls.Add(this.button96);
            this.PersianKeyBoard.Controls.Add(this.button97);
            this.PersianKeyBoard.Controls.Add(this.button98);
            this.PersianKeyBoard.Controls.Add(this.button36);
            this.PersianKeyBoard.Controls.Add(this.Button35);
            this.PersianKeyBoard.Controls.Add(this.Button34);
            this.PersianKeyBoard.Controls.Add(this.Button33);
            this.PersianKeyBoard.Controls.Add(this.Button32);
            this.PersianKeyBoard.Controls.Add(this.Button31);
            this.PersianKeyBoard.Controls.Add(this.Button30);
            this.PersianKeyBoard.Controls.Add(this.Button29);
            this.PersianKeyBoard.Controls.Add(this.Button28);
            this.PersianKeyBoard.Controls.Add(this.Button18);
            this.PersianKeyBoard.Controls.Add(this.Button17);
            this.PersianKeyBoard.Controls.Add(this.Button13);
            this.PersianKeyBoard.Controls.Add(this.Button14);
            this.PersianKeyBoard.Controls.Add(this.Button23);
            this.PersianKeyBoard.Controls.Add(this.Button25);
            this.PersianKeyBoard.Controls.Add(this.Button2);
            this.PersianKeyBoard.Controls.Add(this.Button27);
            this.PersianKeyBoard.Controls.Add(this.Button24);
            this.PersianKeyBoard.Controls.Add(this.Button3);
            this.PersianKeyBoard.Controls.Add(this.Button26);
            this.PersianKeyBoard.Controls.Add(this.Button5);
            this.PersianKeyBoard.Controls.Add(this.Button20);
            this.PersianKeyBoard.Controls.Add(this.Button22);
            this.PersianKeyBoard.Controls.Add(this.Button12);
            this.PersianKeyBoard.Controls.Add(this.Button16);
            this.PersianKeyBoard.Controls.Add(this.Button11);
            this.PersianKeyBoard.Controls.Add(this.Button19);
            this.PersianKeyBoard.Controls.Add(this.Button10);
            this.PersianKeyBoard.Controls.Add(this.Button15);
            this.PersianKeyBoard.Controls.Add(this.Button8);
            this.PersianKeyBoard.Controls.Add(this.Button21);
            this.PersianKeyBoard.Controls.Add(this.Button7);
            this.PersianKeyBoard.Controls.Add(this.Button9);
            this.PersianKeyBoard.Controls.Add(this.Button6);
            this.PersianKeyBoard.Controls.Add(this.Button1);
            this.PersianKeyBoard.Controls.Add(this.Button4);
            this.PersianKeyBoard.Location = new System.Drawing.Point(20, 116);
            this.PersianKeyBoard.Name = "PersianKeyBoard";
            this.PersianKeyBoard.Size = new System.Drawing.Size(357, 121);
            this.PersianKeyBoard.TabIndex = 17;
            // 
            // button86
            // 
            this.button86.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button86.Location = new System.Drawing.Point(312, 3);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(18, 23);
            this.button86.TabIndex = 111;
            this.button86.Text = "+";
            this.button86.UseVisualStyleBackColor = true;
            this.button86.Click += new System.EventHandler(this.button76_Click);
            // 
            // button87
            // 
            this.button87.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button87.Location = new System.Drawing.Point(287, 3);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(19, 23);
            this.button87.TabIndex = 110;
            this.button87.Text = "-";
            this.button87.UseVisualStyleBackColor = true;
            this.button87.Click += new System.EventHandler(this.button76_Click);
            // 
            // button88
            // 
            this.button88.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button88.Location = new System.Drawing.Point(333, 3);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(19, 23);
            this.button88.TabIndex = 109;
            this.button88.Text = "=";
            this.button88.UseVisualStyleBackColor = true;
            this.button88.Click += new System.EventHandler(this.button76_Click);
            // 
            // button89
            // 
            this.button89.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button89.Location = new System.Drawing.Point(28, 3);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(19, 23);
            this.button89.TabIndex = 103;
            this.button89.Text = "1";
            this.button89.UseVisualStyleBackColor = true;
            this.button89.Click += new System.EventHandler(this.button76_Click);
            // 
            // button90
            // 
            this.button90.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button90.Location = new System.Drawing.Point(53, 3);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(19, 23);
            this.button90.TabIndex = 107;
            this.button90.Text = "2";
            this.button90.UseVisualStyleBackColor = true;
            this.button90.Click += new System.EventHandler(this.button76_Click);
            // 
            // button91
            // 
            this.button91.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button91.Location = new System.Drawing.Point(157, 3);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(19, 23);
            this.button91.TabIndex = 108;
            this.button91.Text = "6";
            this.button91.UseVisualStyleBackColor = true;
            this.button91.Click += new System.EventHandler(this.button76_Click);
            // 
            // button92
            // 
            this.button92.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button92.Location = new System.Drawing.Point(79, 3);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(19, 23);
            this.button92.TabIndex = 99;
            this.button92.Text = "3";
            this.button92.UseVisualStyleBackColor = true;
            this.button92.Click += new System.EventHandler(this.button76_Click);
            // 
            // button93
            // 
            this.button93.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button93.Location = new System.Drawing.Point(183, 3);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(19, 23);
            this.button93.TabIndex = 106;
            this.button93.Text = "7";
            this.button93.UseVisualStyleBackColor = true;
            this.button93.Click += new System.EventHandler(this.button76_Click);
            // 
            // button94
            // 
            this.button94.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button94.Location = new System.Drawing.Point(261, 3);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(20, 23);
            this.button94.TabIndex = 102;
            this.button94.Text = "0";
            this.button94.UseVisualStyleBackColor = true;
            this.button94.Click += new System.EventHandler(this.button76_Click);
            // 
            // button95
            // 
            this.button95.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button95.Location = new System.Drawing.Point(105, 3);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(19, 23);
            this.button95.TabIndex = 104;
            this.button95.Text = "4";
            this.button95.UseVisualStyleBackColor = true;
            this.button95.Click += new System.EventHandler(this.button76_Click);
            // 
            // button96
            // 
            this.button96.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button96.Location = new System.Drawing.Point(235, 3);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(20, 23);
            this.button96.TabIndex = 101;
            this.button96.Text = "9";
            this.button96.UseVisualStyleBackColor = true;
            this.button96.Click += new System.EventHandler(this.button76_Click);
            // 
            // button97
            // 
            this.button97.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button97.Location = new System.Drawing.Point(131, 3);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(19, 23);
            this.button97.TabIndex = 105;
            this.button97.Text = "5";
            this.button97.UseVisualStyleBackColor = true;
            this.button97.Click += new System.EventHandler(this.button76_Click);
            // 
            // button98
            // 
            this.button98.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button98.Location = new System.Drawing.Point(209, 3);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(19, 23);
            this.button98.TabIndex = 100;
            this.button98.Text = "8";
            this.button98.UseVisualStyleBackColor = true;
            this.button98.Click += new System.EventHandler(this.button76_Click);
            // 
            // button36
            // 
            this.button36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button36.Location = new System.Drawing.Point(3, 3);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(19, 23);
            this.button36.TabIndex = 98;
            this.button36.Text = "پ";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button35
            // 
            this.Button35.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button35.Location = new System.Drawing.Point(79, 90);
            this.Button35.Name = "Button35";
            this.Button35.Size = new System.Drawing.Size(19, 23);
            this.Button35.TabIndex = 97;
            this.Button35.Text = "ژ";
            this.Button35.UseVisualStyleBackColor = true;
            this.Button35.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button34
            // 
            this.Button34.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button34.Location = new System.Drawing.Point(332, 90);
            this.Button34.Name = "Button34";
            this.Button34.Size = new System.Drawing.Size(19, 23);
            this.Button34.TabIndex = 96;
            this.Button34.Text = "و";
            this.Button34.UseVisualStyleBackColor = true;
            this.Button34.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button33
            // 
            this.Button33.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button33.Location = new System.Drawing.Point(261, 61);
            this.Button33.Name = "Button33";
            this.Button33.Size = new System.Drawing.Size(19, 23);
            this.Button33.TabIndex = 95;
            this.Button33.Text = "گ";
            this.Button33.UseVisualStyleBackColor = true;
            this.Button33.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button32
            // 
            this.Button32.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button32.Location = new System.Drawing.Point(235, 61);
            this.Button32.Name = "Button32";
            this.Button32.Size = new System.Drawing.Size(19, 23);
            this.Button32.TabIndex = 94;
            this.Button32.Text = "ک";
            this.Button32.UseVisualStyleBackColor = true;
            this.Button32.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button31
            // 
            this.Button31.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button31.Location = new System.Drawing.Point(286, 32);
            this.Button31.Name = "Button31";
            this.Button31.Size = new System.Drawing.Size(19, 23);
            this.Button31.TabIndex = 93;
            this.Button31.Text = "چ";
            this.Button31.UseVisualStyleBackColor = true;
            this.Button31.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button30
            // 
            this.Button30.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button30.Location = new System.Drawing.Point(261, 32);
            this.Button30.Name = "Button30";
            this.Button30.Size = new System.Drawing.Size(19, 23);
            this.Button30.TabIndex = 92;
            this.Button30.Text = "ج";
            this.Button30.UseVisualStyleBackColor = true;
            this.Button30.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button29
            // 
            this.Button29.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button29.Location = new System.Drawing.Point(311, 32);
            this.Button29.Name = "Button29";
            this.Button29.Size = new System.Drawing.Size(41, 23);
            this.Button29.TabIndex = 91;
            this.Button29.Text = "<---";
            this.Button29.UseVisualStyleBackColor = true;
            this.Button29.Click += new System.EventHandler(this.button44_Click);
            // 
            // Button28
            // 
            this.Button28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button28.Location = new System.Drawing.Point(131, 90);
            this.Button28.Name = "Button28";
            this.Button28.Size = new System.Drawing.Size(123, 23);
            this.Button28.TabIndex = 90;
            this.Button28.Text = "فاصله";
            this.Button28.UseVisualStyleBackColor = true;
            this.Button28.Click += new System.EventHandler(this.button45_Click);
            // 
            // Button18
            // 
            this.Button18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button18.Location = new System.Drawing.Point(286, 61);
            this.Button18.Name = "Button18";
            this.Button18.Size = new System.Drawing.Size(65, 23);
            this.Button18.TabIndex = 89;
            this.Button18.Text = "اینتر";
            this.Button18.UseVisualStyleBackColor = true;
            this.Button18.Click += new System.EventHandler(this.button46_Click);
            // 
            // Button17
            // 
            this.Button17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button17.Location = new System.Drawing.Point(2, 32);
            this.Button17.Name = "Button17";
            this.Button17.Size = new System.Drawing.Size(19, 23);
            this.Button17.TabIndex = 79;
            this.Button17.Text = "ض";
            this.Button17.UseVisualStyleBackColor = true;
            this.Button17.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button13
            // 
            this.Button13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button13.Location = new System.Drawing.Point(309, 90);
            this.Button13.Name = "Button13";
            this.Button13.Size = new System.Drawing.Size(19, 23);
            this.Button13.TabIndex = 75;
            this.Button13.Text = "ئ";
            this.Button13.UseVisualStyleBackColor = true;
            this.Button13.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button14
            // 
            this.Button14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button14.Location = new System.Drawing.Point(286, 90);
            this.Button14.Name = "Button14";
            this.Button14.Size = new System.Drawing.Size(19, 23);
            this.Button14.TabIndex = 76;
            this.Button14.Text = "د";
            this.Button14.UseVisualStyleBackColor = true;
            this.Button14.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button23
            // 
            this.Button23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button23.Location = new System.Drawing.Point(104, 90);
            this.Button23.Name = "Button23";
            this.Button23.Size = new System.Drawing.Size(19, 23);
            this.Button23.TabIndex = 84;
            this.Button23.Text = "ر";
            this.Button23.UseVisualStyleBackColor = true;
            this.Button23.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button25
            // 
            this.Button25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button25.Location = new System.Drawing.Point(27, 90);
            this.Button25.Name = "Button25";
            this.Button25.Size = new System.Drawing.Size(19, 23);
            this.Button25.TabIndex = 86;
            this.Button25.Text = "ط";
            this.Button25.UseVisualStyleBackColor = true;
            this.Button25.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button2
            // 
            this.Button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button2.Location = new System.Drawing.Point(262, 90);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(19, 23);
            this.Button2.TabIndex = 64;
            this.Button2.Text = "ذ";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button27
            // 
            this.Button27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button27.Location = new System.Drawing.Point(3, 90);
            this.Button27.Name = "Button27";
            this.Button27.Size = new System.Drawing.Size(19, 23);
            this.Button27.TabIndex = 88;
            this.Button27.Text = "ظ";
            this.Button27.UseVisualStyleBackColor = true;
            this.Button27.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button24
            // 
            this.Button24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button24.Location = new System.Drawing.Point(27, 32);
            this.Button24.Name = "Button24";
            this.Button24.Size = new System.Drawing.Size(19, 23);
            this.Button24.TabIndex = 85;
            this.Button24.Text = "ص";
            this.Button24.UseVisualStyleBackColor = true;
            this.Button24.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button3
            // 
            this.Button3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button3.Location = new System.Drawing.Point(52, 90);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(19, 23);
            this.Button3.TabIndex = 65;
            this.Button3.Text = "ز";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button26
            // 
            this.Button26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button26.Location = new System.Drawing.Point(131, 32);
            this.Button26.Name = "Button26";
            this.Button26.Size = new System.Drawing.Size(19, 23);
            this.Button26.TabIndex = 87;
            this.Button26.Text = "غ";
            this.Button26.UseVisualStyleBackColor = true;
            this.Button26.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button5
            // 
            this.Button5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button5.Location = new System.Drawing.Point(53, 32);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(19, 23);
            this.Button5.TabIndex = 67;
            this.Button5.Text = "ث";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button20
            // 
            this.Button20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button20.Location = new System.Drawing.Point(27, 61);
            this.Button20.Name = "Button20";
            this.Button20.Size = new System.Drawing.Size(19, 23);
            this.Button20.TabIndex = 81;
            this.Button20.Text = "س";
            this.Button20.UseVisualStyleBackColor = true;
            this.Button20.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button22
            // 
            this.Button22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button22.Location = new System.Drawing.Point(157, 32);
            this.Button22.Name = "Button22";
            this.Button22.Size = new System.Drawing.Size(19, 23);
            this.Button22.TabIndex = 83;
            this.Button22.Text = "ع";
            this.Button22.UseVisualStyleBackColor = true;
            this.Button22.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button12
            // 
            this.Button12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button12.Location = new System.Drawing.Point(208, 61);
            this.Button12.Name = "Button12";
            this.Button12.Size = new System.Drawing.Size(19, 23);
            this.Button12.TabIndex = 74;
            this.Button12.Text = "م";
            this.Button12.UseVisualStyleBackColor = true;
            this.Button12.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button16
            // 
            this.Button16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button16.Location = new System.Drawing.Point(235, 32);
            this.Button16.Name = "Button16";
            this.Button16.Size = new System.Drawing.Size(20, 23);
            this.Button16.TabIndex = 78;
            this.Button16.Text = "ح";
            this.Button16.UseVisualStyleBackColor = true;
            this.Button16.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button11
            // 
            this.Button11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button11.Location = new System.Drawing.Point(183, 61);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(19, 23);
            this.Button11.TabIndex = 73;
            this.Button11.Text = "ن";
            this.Button11.UseVisualStyleBackColor = true;
            this.Button11.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button19
            // 
            this.Button19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button19.Location = new System.Drawing.Point(79, 32);
            this.Button19.Name = "Button19";
            this.Button19.Size = new System.Drawing.Size(19, 23);
            this.Button19.TabIndex = 80;
            this.Button19.Text = "ق";
            this.Button19.UseVisualStyleBackColor = true;
            this.Button19.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button10
            // 
            this.Button10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button10.Location = new System.Drawing.Point(157, 61);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(19, 23);
            this.Button10.TabIndex = 72;
            this.Button10.Text = "ت";
            this.Button10.UseVisualStyleBackColor = true;
            this.Button10.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button15
            // 
            this.Button15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button15.Location = new System.Drawing.Point(209, 32);
            this.Button15.Name = "Button15";
            this.Button15.Size = new System.Drawing.Size(20, 23);
            this.Button15.TabIndex = 77;
            this.Button15.Text = "خ";
            this.Button15.UseVisualStyleBackColor = true;
            this.Button15.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button8
            // 
            this.Button8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button8.Location = new System.Drawing.Point(131, 61);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(19, 23);
            this.Button8.TabIndex = 70;
            this.Button8.Text = "ا";
            this.Button8.UseVisualStyleBackColor = true;
            this.Button8.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button21
            // 
            this.Button21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button21.Location = new System.Drawing.Point(105, 32);
            this.Button21.Name = "Button21";
            this.Button21.Size = new System.Drawing.Size(19, 23);
            this.Button21.TabIndex = 82;
            this.Button21.Text = "ف";
            this.Button21.UseVisualStyleBackColor = true;
            this.Button21.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button7
            // 
            this.Button7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button7.Location = new System.Drawing.Point(105, 61);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(19, 23);
            this.Button7.TabIndex = 69;
            this.Button7.Text = "ل";
            this.Button7.UseVisualStyleBackColor = true;
            this.Button7.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button9
            // 
            this.Button9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button9.Location = new System.Drawing.Point(183, 32);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(19, 23);
            this.Button9.TabIndex = 71;
            this.Button9.Text = "ه";
            this.Button9.UseVisualStyleBackColor = true;
            this.Button9.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button6
            // 
            this.Button6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button6.Location = new System.Drawing.Point(79, 61);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(19, 23);
            this.Button6.TabIndex = 68;
            this.Button6.Text = "ب";
            this.Button6.UseVisualStyleBackColor = true;
            this.Button6.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button1
            // 
            this.Button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button1.Location = new System.Drawing.Point(2, 61);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(19, 23);
            this.Button1.TabIndex = 63;
            this.Button1.Text = "ش";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.button76_Click);
            // 
            // Button4
            // 
            this.Button4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Button4.Location = new System.Drawing.Point(53, 61);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(19, 23);
            this.Button4.TabIndex = 66;
            this.Button4.Text = "ی";
            this.Button4.UseVisualStyleBackColor = true;
            this.Button4.Click += new System.EventHandler(this.button76_Click);
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(69, 18);
            this.toolStripStatusLabel3.Text = "Characters :";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 23);
            // 
            // Characters
            // 
            this.Characters.Name = "Characters";
            this.Characters.Size = new System.Drawing.Size(13, 18);
            this.Characters.Text = "0";
            this.Characters.ToolTipText = "تعداد حروف نوشته شده";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 23);
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(40, 18);
            this.toolStripStatusLabel5.Text = "Lines :";
            // 
            // Lines
            // 
            this.Lines.Name = "Lines";
            this.Lines.Size = new System.Drawing.Size(13, 18);
            this.Lines.Text = "0";
            this.Lines.ToolTipText = "تعداد خط نوشته شده";
            // 
            // KeyBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 265);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.Pic_Copy);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.PicExit);
            this.Controls.Add(this.PersianKeyBoard);
            this.Controls.Add(this.EnglishKeyBoard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "KeyBoard";
            this.Text = "KeyBoard";
            this.Load += new System.EventHandler(this.KeyBoard_Load);
            this.EnglishKeyBoard.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PicExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_Copy)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.PersianKeyBoard.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel EnglishKeyBoard;
        internal System.Windows.Forms.Button button73;
        internal System.Windows.Forms.Button button74;
        internal System.Windows.Forms.Button button75;
        internal System.Windows.Forms.Button button76;
        internal System.Windows.Forms.Button button77;
        internal System.Windows.Forms.Button button78;
        internal System.Windows.Forms.Button button79;
        internal System.Windows.Forms.Button button80;
        internal System.Windows.Forms.Button button81;
        internal System.Windows.Forms.Button button82;
        internal System.Windows.Forms.Button button83;
        internal System.Windows.Forms.Button button84;
        internal System.Windows.Forms.Button button85;
        internal System.Windows.Forms.Button button37;
        internal System.Windows.Forms.Button button38;
        internal System.Windows.Forms.Button button39;
        internal System.Windows.Forms.Button button40;
        internal System.Windows.Forms.Button button41;
        internal System.Windows.Forms.Button button42;
        internal System.Windows.Forms.Button button43;
        internal System.Windows.Forms.Button button44;
        internal System.Windows.Forms.Button button45;
        internal System.Windows.Forms.Button button46;
        internal System.Windows.Forms.Button button47;
        internal System.Windows.Forms.Button button48;
        internal System.Windows.Forms.Button button49;
        internal System.Windows.Forms.Button button50;
        internal System.Windows.Forms.Button button51;
        internal System.Windows.Forms.Button button52;
        internal System.Windows.Forms.Button button53;
        internal System.Windows.Forms.Button button54;
        internal System.Windows.Forms.Button button55;
        internal System.Windows.Forms.Button button56;
        internal System.Windows.Forms.Button button57;
        internal System.Windows.Forms.Button button58;
        internal System.Windows.Forms.Button button59;
        internal System.Windows.Forms.Button button60;
        internal System.Windows.Forms.Button button61;
        internal System.Windows.Forms.Button button62;
        internal System.Windows.Forms.Button button63;
        internal System.Windows.Forms.Button button64;
        internal System.Windows.Forms.Button button65;
        internal System.Windows.Forms.Button button66;
        internal System.Windows.Forms.Button button67;
        internal System.Windows.Forms.Button button68;
        internal System.Windows.Forms.Button button69;
        internal System.Windows.Forms.Button button70;
        internal System.Windows.Forms.Button button71;
        internal System.Windows.Forms.Button button72;
        private System.Windows.Forms.PictureBox PicExit;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.PictureBox Pic_Copy;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem Left;
        private System.Windows.Forms.ToolStripMenuItem Center;
        private System.Windows.Forms.ToolStripMenuItem Right;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton2;
        private System.Windows.Forms.ToolStripMenuItem Persian;
        private System.Windows.Forms.ToolStripMenuItem Engilsh;
        private System.Windows.Forms.Panel PersianKeyBoard;
        internal System.Windows.Forms.Button button86;
        internal System.Windows.Forms.Button button87;
        internal System.Windows.Forms.Button button88;
        internal System.Windows.Forms.Button button89;
        internal System.Windows.Forms.Button button90;
        internal System.Windows.Forms.Button button91;
        internal System.Windows.Forms.Button button92;
        internal System.Windows.Forms.Button button93;
        internal System.Windows.Forms.Button button94;
        internal System.Windows.Forms.Button button95;
        internal System.Windows.Forms.Button button96;
        internal System.Windows.Forms.Button button97;
        internal System.Windows.Forms.Button button98;
        internal System.Windows.Forms.Button button36;
        internal System.Windows.Forms.Button Button35;
        internal System.Windows.Forms.Button Button34;
        internal System.Windows.Forms.Button Button33;
        internal System.Windows.Forms.Button Button32;
        internal System.Windows.Forms.Button Button31;
        internal System.Windows.Forms.Button Button30;
        internal System.Windows.Forms.Button Button29;
        internal System.Windows.Forms.Button Button28;
        internal System.Windows.Forms.Button Button18;
        internal System.Windows.Forms.Button Button17;
        internal System.Windows.Forms.Button Button13;
        internal System.Windows.Forms.Button Button14;
        internal System.Windows.Forms.Button Button23;
        internal System.Windows.Forms.Button Button25;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button27;
        public System.Windows.Forms.Button Button24;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button26;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Button Button20;
        internal System.Windows.Forms.Button Button22;
        internal System.Windows.Forms.Button Button12;
        internal System.Windows.Forms.Button Button16;
        internal System.Windows.Forms.Button Button11;
        internal System.Windows.Forms.Button Button19;
        internal System.Windows.Forms.Button Button10;
        internal System.Windows.Forms.Button Button15;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.Button Button21;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Button Button4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel Characters;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel Lines;
    }
}